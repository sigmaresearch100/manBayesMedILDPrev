library(testthat)
library(manBayesMedILDPrev)

test_check("manBayesMedILDPrev")
